# Scientific status

This pack is only for the finite upper-bound certificate.

It does not use the NormalFormA structure.

If it proves UNSAT, the result combines with the known 108-point AP-free survivor to give:

\[
\alpha(T_{19,8}^{(5,4)}) = 108.
\]

Without UNSAT proof verification, this remains open.
