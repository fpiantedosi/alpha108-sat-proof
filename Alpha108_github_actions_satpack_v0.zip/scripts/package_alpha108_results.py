#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import datetime
import zipfile

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

root = Path("alpha108_run")
files = []
for name in [
    "alpha108_no109.cnf",
    "alpha108_no109.drat",
    "alpha108_no109.lrat",
    "cadical.log",
    "drat_trim.log",
    "alpha108_model_manifest.json",
    "alpha108_variable_map.csv",
    "alpha108_ap_constraints.csv",
]:
    p = root / name
    if p.exists():
        files.append(p)

metadata = {
    "created_at": datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds"),
    "files": [
        {"file": str(p), "sha256": sha256_file(p), "bytes": p.stat().st_size}
        for p in files
    ],
    "required_final_status": "UNSAT proof verified by an independent checker",
}

(root / "alpha108_result_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
files.append(root / "alpha108_result_metadata.json")

zip_path = Path("alpha108_results_bundle.zip")
if zip_path.exists():
    zip_path.unlink()

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p)

print(json.dumps(metadata, indent=2))
print("Packed", zip_path)
